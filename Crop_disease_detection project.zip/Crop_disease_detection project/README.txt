#Machine learning models

Model Files:
Rice model: https://drive.google.com/file/d/1N8mWjEjLwGYHgWoR0YLG6qWgd2xxsJuW/view?usp=drive_link

How to use:
1. Download the models from the above links.
2. Put them inside the model folder.
3. Run the project using:
       python app.py